# منظومة البلدية الذكية — تطبيق المواطن (MVP)

تطبيق Flutter عربي RTL للمواطن، مع خادم REST خاص مبني بـ Node.js/Express وقاعدة PostgreSQL.
هذه نقطة بداية قابلة للتشغيل والتطوير، وليست منظومة إنتاجية مكتملة أو تكاملًا حكوميًا رسميًا.

## المحتويات
- `citizen_app/`: تطبيق Flutter (تسجيل/دخول، عرض البلاغات، إنشاء بلاغ، التقاط صورة اختياريًا، الحصول على GPS).
- `server/`: API مع JWT وتجزئة كلمات المرور بـ bcrypt ورفع صور البلاغات.
- `server/db/schema.sql`: مخطط PostgreSQL.
- `docker-compose.yml`: تشغيل PostgreSQL محليًا عبر Docker.

## المتطلبات
- Flutter SDK وAndroid Studio / Android SDK.
- Node.js 20+ وnpm.
- Docker Desktop (اختياري لتشغيل PostgreSQL بسهولة).

## 1) إعداد قاعدة البيانات والخادم

من مجلد المشروع:
```bash
docker compose up -d db
cd server
cp .env.example .env
npm install
npm run db:init
npm run dev
```
الخادم يعمل افتراضيًا على `http://localhost:3000`.

إذا لم تستخدم Docker، أنشئ قاعدة PostgreSQL باسم `municipality`، ثم اضبط `DATABASE_URL` في `server/.env`.

> قبل النشر: غيّر `JWT_SECRET` إلى قيمة طويلة وعشوائية، واستخدم HTTPS، ولا تترك CORS مفتوحًا، وأضف النسخ الاحتياطي ومراقبة السجلات وحدود المعدل وسياسة احتفاظ بالملفات.

## 2) تجهيز وتشغيل تطبيق Flutter

ملفات Android الأساسية تختلف حسب إصدار Flutter. من داخل مجلد التطبيق أنشئ ملفات المنصة أولًا (إذا كان Flutter يطلب ذلك أو ظهرت ملفات Android ناقصة):

```bash
cd citizen_app
flutter create --platforms=android .
flutter pub get
flutter run
```

بعد الأمر `flutter create`، تأكد من وجود أذونات `INTERNET` و`ACCESS_COARSE_LOCATION` و`ACCESS_FINE_LOCATION` و`CAMERA` في `android/app/src/main/AndroidManifest.xml`، ومن وجود `android:usesCleartextTraffic="true"` للتجربة المحلية فقط. لا تستخدم HTTP في الإنتاج.

### عنوان API
- Android Emulator: `http://10.0.2.2:3000/api`
- هاتف حقيقي: ضع عنوان IP المحلي للكمبيوتر بدل `10.0.2.2`، مثل `http://192.168.1.20:3000/api`، واجعل الهاتف والكمبيوتر على الشبكة نفسها.
- غيّر `ApiConfig.baseUrl` في `lib/config/api_config.dart`.

للتجربة المحلية عبر HTTP، أُضيف `usesCleartextTraffic="true"` إلى Manifest. لا تستخدم HTTP في الإنتاج.

## 3) بناء APK
من مجلد `citizen_app`:
```bash
flutter doctor
flutter pub get
flutter build apk --release
```
الملف الناتج:
`citizen_app/build/app/outputs/flutter-apk/app-release.apk`

لإنتاج APK للنشر العام، أنشئ مفتاح توقيع Android خاصًا بك واضبط إعدادات التوقيع في Gradle. لا تضع مفاتيح التوقيع أو الأسرار في المستودع.

## واجهات API الأساسية
- `POST /api/auth/register` `{ "name", "email", "phone", "password" }`
- `POST /api/auth/login` `{ "email", "password" }`
- `GET /api/reports` (JWT)
- `POST /api/reports` (JWT، multipart: `title`, `description`, `category`, `latitude`, `longitude`, `image` اختياري)
- `GET /api/health`

## ملاحظات مهمة
- OTP والهوية الرقمية والدفع الإلكتروني والإشعارات الفورية غير مفعّلة في هذه النسخة؛ تتطلب مزودًا موثوقًا وتكاملًا خلفيًا.
- تحديد الموقع يتطلب إذن المستخدم. لا يُرسل الموقع إلا عند إنشاء البلاغ.
- الملفات المرفوعة تُخزن محليًا في `server/uploads` للتطوير؛ استخدم تخزين ملفات خاصًا وآمنًا في الإنتاج.
- أضف اختبارات، سياسة خصوصية، شروط استخدام، وتحققًا قانونيًا/أمنيًا قبل الإطلاق.
