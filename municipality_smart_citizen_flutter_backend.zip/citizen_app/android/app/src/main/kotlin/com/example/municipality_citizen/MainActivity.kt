package com.example.municipality_citizen

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
